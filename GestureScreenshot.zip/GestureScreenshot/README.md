# Gesture Screenshot

Front camera detects a hand gesture (✋ Open Palm, 👍 Thumbs Up, or ✌️ Victory) using
Google MediaPipe's Gesture Recognizer, and when the gesture you selected is seen, the
app silently captures the current screen via the MediaProjection API and saves it to
the Gallery (`Pictures/GestureScreenshots`). A 2-second cooldown prevents burst captures.

Built with Kotlin, CameraX, and MediaPipe Tasks Vision. Targets Android 13/14
(minSdk 26 / targetSdk 34) and has been laid out for the Samsung Galaxy Tab A9+.

## One unavoidable step: the screen-capture consent dialog

Android requires the user to explicitly grant screen-recording/capture access via a
system dialog (`MediaProjectionManager.createScreenCaptureIntent()`). **This single tap
per app session is an OS-level security control and cannot be bypassed or automated by
any app** — Google does not allow silently granted screen capture, for obvious privacy
reasons. Once that one tap happens, every screenshot after it is fully silent: no
further screen touches, only your hand gesture in front of the camera.

## Required setup before building

1. **Download the gesture recognition model.** This project does not bundle it (it's
   ~10 MB and must come straight from Google). Download `gesture_recognizer.task` from:
   https://storage.googleapis.com/mediapipe-models/gesture_recognizer/gesture_recognizer/float16/latest/gesture_recognizer.task
   and place it at:
   ```
   app/src/main/assets/gesture_recognizer.task
   ```
   (create the `assets` folder if it doesn't exist).

2. **Open in Android Studio** (Koala/2024.1+ recommended), let Gradle sync pull down
   CameraX 1.3.4 and `com.google.mediapipe:tasks-vision:0.10.14`.

3. **Run on the Tab A9+** with USB debugging enabled, or build an APK
   (`Build > Build Bundle(s)/APK(s) > Build APK(s)`) and sideload it.

## How it works

- `MainActivity` — UI (gesture picker + start/stop), requests CAMERA permission,
  launches the MediaProjection consent flow, and wires CameraX frames into the
  gesture recognizer.
- `GestureRecognizerHelper` — thin wrapper around MediaPipe's `GestureRecognizer`
  running in `LIVE_STREAM` mode; emits `(gestureName, confidenceScore)` per frame.
- `ScreenshotCaptureService` — a foreground service (required by Android for any
  app using MediaProjection) that owns the `MediaProjection` → `VirtualDisplay` →
  `ImageReader` pipeline and grabs a single frame on demand.
- `ScreenshotSaver` — writes the captured `Bitmap` into the Gallery via `MediaStore`.

Recognized gesture names from Google's pretrained model: `Open_Palm`, `Thumb_Up`,
`Victory` (plus `Closed_Fist`, `Pointing_Up`, `ILoveYou`, `None` — unused here).

## Tuning

- **Confidence threshold**: `handleGestureResult()` in `MainActivity.kt` requires
  `score >= 0.6f`. Raise it if you get false triggers, lower it if real gestures
  aren't being recognized.
- **Cooldown**: `cooldownMs = 2000L` in `MainActivity.kt`.
- **Capture resolution**: matches the device's real screen metrics automatically.

## Samsung-specific notes

- One UI's battery optimization can kill background services aggressively. If
  monitoring stops unexpectedly, add the app to "Unrestricted" battery usage under
  Settings > Apps > Gesture Screenshot > Battery.
- The Tab A9+'s front camera is fine for MediaPipe's hand landmark model at typical
  arm's-length distances; keep the hand fully in frame for reliable recognition.

## Permissions requested

| Permission | Why |
|---|---|
| `CAMERA` | Live front-camera feed for gesture detection |
| `FOREGROUND_SERVICE` / `FOREGROUND_SERVICE_MEDIA_PROJECTION` | Required to hold a MediaProjection session |
| `POST_NOTIFICATIONS` | Foreground service must show a notification (Android 13+) |
| `WRITE_EXTERNAL_STORAGE` (maxSdk 28 only) | Pre-scoped-storage gallery writes |
| MediaProjection consent (system dialog, not a manifest permission) | One-time, required by Android for any screen capture |
