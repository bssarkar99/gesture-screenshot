package com.example.gesturescreenshot

import android.content.Context
import android.graphics.Bitmap
import com.google.mediapipe.framework.image.BitmapImageBuilder
import com.google.mediapipe.framework.image.MPImage
import com.google.mediapipe.tasks.core.BaseOptions
import com.google.mediapipe.tasks.core.Delegate
import com.google.mediapipe.tasks.vision.core.RunningMode
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizer
import com.google.mediapipe.tasks.vision.gesturerecognizer.GestureRecognizerResult

/**
 * Wraps MediaPipe's GestureRecognizer running in LIVE_STREAM mode so CameraX
 * frames can be streamed in continuously, with recognized gestures arriving
 * asynchronously through [onResult].
 *
 * Requires gesture_recognizer.task to be present in app/src/main/assets/.
 * Download it from Google's MediaPipe model page (see README.md).
 */
class GestureRecognizerHelper(
    context: Context,
    private val onResult: (gestureName: String, score: Float) -> Unit,
    private val onError: (message: String) -> Unit
) {

    private var gestureRecognizer: GestureRecognizer? = null

    init {
        try {
            val baseOptions = BaseOptions.builder()
                .setModelAssetPath(MODEL_PATH)
                .setDelegate(Delegate.CPU)
                .build()

            val options = GestureRecognizer.GestureRecognizerOptions.builder()
                .setBaseOptions(baseOptions)
                .setRunningMode(RunningMode.LIVE_STREAM)
                .setNumHands(1)
                .setMinHandDetectionConfidence(0.5f)
                .setMinTrackingConfidence(0.5f)
                .setMinHandPresenceConfidence(0.5f)
                .setResultListener(::handleResult)
                .setErrorListener { e -> onError(e.message ?: "Unknown gesture recognizer error") }
                .build()

            gestureRecognizer = GestureRecognizer.createFromOptions(context, options)
        } catch (e: Exception) {
            onError("Failed to initialize GestureRecognizer: ${e.message}")
        }
    }

    /** Feed a single CameraX frame in. Safe to call repeatedly from an analyzer thread. */
    fun recognizeAsync(bitmap: Bitmap, timestampMs: Long) {
        val mpImage: MPImage = BitmapImageBuilder(bitmap).build()
        gestureRecognizer?.recognizeAsync(mpImage, timestampMs)
    }

    private fun handleResult(result: GestureRecognizerResult, input: MPImage) {
        val gestures = result.gestures()
        if (gestures.isNotEmpty() && gestures[0].isNotEmpty()) {
            val topGesture = gestures[0][0]
            onResult(topGesture.categoryName(), topGesture.score())
        }
    }

    fun close() {
        gestureRecognizer?.close()
        gestureRecognizer = null
    }

    companion object {
        const val MODEL_PATH = "gesture_recognizer.task"

        // Category names produced by Google's pretrained gesture_recognizer.task model.
        const val GESTURE_OPEN_PALM = "Open_Palm"
        const val GESTURE_THUMBS_UP = "Thumb_Up"
        const val GESTURE_VICTORY = "Victory"
    }
}
