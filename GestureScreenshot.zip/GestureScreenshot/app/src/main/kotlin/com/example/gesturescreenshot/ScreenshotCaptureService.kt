package com.example.gesturescreenshot

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.Image
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Binder
import android.os.Build
import android.os.IBinder
import android.util.Log
import androidx.core.app.NotificationCompat

/**
 * Foreground service that owns the MediaProjection session and grabs a single
 * frame from a VirtualDisplay on demand (called when a gesture is recognized).
 * A foreground service + notification is mandatory for MediaProjection on
 * Android 10+; this is the one persistent, user-visible sign that capture is
 * active, but it does not require touching the screen to take a shot.
 */
class ScreenshotCaptureService : Service() {

    inner class LocalBinder : Binder() {
        fun getService(): ScreenshotCaptureService = this@ScreenshotCaptureService
    }

    private val binder = LocalBinder()

    private var mediaProjection: MediaProjection? = null
    private var virtualDisplay: VirtualDisplay? = null
    private var imageReader: ImageReader? = null

    private var screenWidth = 0
    private var screenHeight = 0

    override fun onBind(intent: Intent?): IBinder = binder

    override fun onCreate() {
        super.onCreate()
        startForeground(NOTIFICATION_ID, buildNotification())
    }

    /** Call once, immediately after the user grants the MediaProjection consent dialog. */
    fun startProjection(resultCode: Int, data: Intent, width: Int, height: Int, density: Int) {
        screenWidth = width
        screenHeight = height

        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjection = projectionManager.getMediaProjection(resultCode, data)
        mediaProjection?.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                tearDownVirtualDisplay()
            }
        }, null)

        imageReader = ImageReader.newInstance(width, height, PixelFormat.RGBA_8888, 2)
        virtualDisplay = mediaProjection?.createVirtualDisplay(
            "GestureScreenshotDisplay",
            width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            imageReader?.surface,
            null, null
        )
    }

    /**
     * Grabs the most recent frame from the virtual display, converts it to a
     * Bitmap, and saves it to the Gallery. Returns true on success.
     */
    fun captureScreenshot(): Boolean {
        val reader = imageReader ?: return false
        val image: Image = reader.acquireLatestImage() ?: return false

        return try {
            val bitmap = imageToBitmap(image)
            image.close()
            ScreenshotSaver.saveBitmapToGallery(applicationContext, bitmap)
            true
        } catch (e: Exception) {
            Log.e(TAG, "Failed to capture screenshot", e)
            image.close()
            false
        }
    }

    private fun imageToBitmap(image: Image): Bitmap {
        val plane = image.planes[0]
        val buffer = plane.buffer
        val pixelStride = plane.pixelStride
        val rowStride = plane.rowStride
        val rowPadding = rowStride - pixelStride * screenWidth

        val bitmap = Bitmap.createBitmap(
            screenWidth + rowPadding / pixelStride,
            screenHeight,
            Bitmap.Config.ARGB_8888
        )
        bitmap.copyPixelsFromBuffer(buffer)

        // Crop away the row padding so the final image matches the real screen size.
        return Bitmap.createBitmap(bitmap, 0, 0, screenWidth, screenHeight)
    }

    private fun tearDownVirtualDisplay() {
        virtualDisplay?.release()
        virtualDisplay = null
        imageReader?.close()
        imageReader = null
    }

    override fun onDestroy() {
        tearDownVirtualDisplay()
        mediaProjection?.stop()
        mediaProjection = null
        super.onDestroy()
    }

    private fun buildNotification(): Notification {
        val channelId = "gesture_screenshot_channel"
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val channel = NotificationChannel(
                channelId,
                "Gesture Screenshot Service",
                NotificationManager.IMPORTANCE_LOW
            )
            val manager = getSystemService(NotificationManager::class.java)
            manager.createNotificationChannel(channel)
        }

        return NotificationCompat.Builder(this, channelId)
            .setContentTitle("Gesture Screenshot active")
            .setContentText("Watching for your selected hand gesture")
            .setSmallIcon(android.R.drawable.ic_menu_camera)
            .setOngoing(true)
            .build()
    }

    companion object {
        private const val TAG = "ScreenshotService"
        const val NOTIFICATION_ID = 42
    }
}
