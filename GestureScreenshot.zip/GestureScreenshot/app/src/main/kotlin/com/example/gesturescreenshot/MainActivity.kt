package com.example.gesturescreenshot

import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.content.ServiceConnection
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.ImageFormat
import android.graphics.Matrix
import android.graphics.Rect
import android.graphics.YuvImage
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Bundle
import android.os.IBinder
import android.util.DisplayMetrics
import android.util.Log
import android.widget.Button
import android.widget.RadioGroup
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import androidx.camera.core.CameraSelector
import androidx.camera.core.ImageAnalysis
import androidx.camera.core.ImageProxy
import androidx.camera.core.Preview
import androidx.camera.lifecycle.ProcessCameraProvider
import androidx.camera.view.PreviewView
import androidx.core.content.ContextCompat
import java.io.ByteArrayOutputStream
import java.util.concurrent.ExecutorService
import java.util.concurrent.Executors

class MainActivity : AppCompatActivity() {

    private lateinit var previewView: PreviewView
    private lateinit var statusText: TextView
    private lateinit var toggleButton: Button
    private lateinit var gestureRadioGroup: RadioGroup

    private var cameraProvider: ProcessCameraProvider? = null
    private var gestureRecognizerHelper: GestureRecognizerHelper? = null
    private val cameraExecutor: ExecutorService = Executors.newSingleThreadExecutor()

    private var isMonitoring = false
    private var lastCaptureTimeMs = 0L
    private val cooldownMs = 2000L // 2-second cooldown between screenshots

    private var selectedGesture = GestureRecognizerHelper.GESTURE_OPEN_PALM

    // --- Bound connection to the screenshot-capturing foreground service ---
    private var screenshotService: ScreenshotCaptureService? = null
    private var isServiceBound = false

    private val serviceConnection = object : ServiceConnection {
        override fun onServiceConnected(name: ComponentName?, service: IBinder?) {
            val binder = service as ScreenshotCaptureService.LocalBinder
            screenshotService = binder.getService()
            isServiceBound = true
        }

        override fun onServiceDisconnected(name: ComponentName?) {
            screenshotService = null
            isServiceBound = false
        }
    }

    private val cameraPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
            if (granted) requestMediaProjection()
            else Toast.makeText(this, "Camera permission is required", Toast.LENGTH_SHORT).show()
        }

    private val notificationPermissionLauncher =
        registerForActivityResult(ActivityResultContracts.RequestPermission()) { /* no-op */ }

    // One-time system consent dialog for screen capture. This tap cannot be
    // skipped or automated - it's an Android platform security requirement.
    private val mediaProjectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == RESULT_OK && result.data != null) {
                val metrics = DisplayMetrics()
                @Suppress("DEPRECATION")
                windowManager.defaultDisplay.getRealMetrics(metrics)

                val serviceIntent = Intent(this, ScreenshotCaptureService::class.java)
                ContextCompat.startForegroundService(this, serviceIntent)
                bindService(serviceIntent, serviceConnection, Context.BIND_AUTO_CREATE)

                val resultCode = result.resultCode
                val data = result.data!!

                previewView.postDelayed({
                    screenshotService?.startProjection(
                        resultCode, data,
                        metrics.widthPixels, metrics.heightPixels, metrics.densityDpi
                    )
                    startCameraAndGestureRecognition()
                }, 300)
            } else {
                Toast.makeText(this, "Screen capture permission denied", Toast.LENGTH_SHORT).show()
            }
        }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        previewView = findViewById(R.id.previewView)
        statusText = findViewById(R.id.statusText)
        toggleButton = findViewById(R.id.btnToggleMonitoring)
        gestureRadioGroup = findViewById(R.id.gestureRadioGroup)

        gestureRadioGroup.setOnCheckedChangeListener { _, checkedId ->
            selectedGesture = when (checkedId) {
                R.id.radioThumbsUp -> GestureRecognizerHelper.GESTURE_THUMBS_UP
                R.id.radioVictory -> GestureRecognizerHelper.GESTURE_VICTORY
                else -> GestureRecognizerHelper.GESTURE_OPEN_PALM
            }
            if (isMonitoring) {
                statusText.text = "Status: monitoring for ${gestureLabel(selectedGesture)}"
            }
        }

        toggleButton.setOnClickListener {
            if (!isMonitoring) requestPermissionsAndStart() else stopMonitoring()
        }

        if (Build.VERSION.SDK_INT >= 33) {
            notificationPermissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS)
        }
    }

    private fun requestPermissionsAndStart() {
        if (ContextCompat.checkSelfPermission(this, android.Manifest.permission.CAMERA)
            != PackageManager.PERMISSION_GRANTED
        ) {
            cameraPermissionLauncher.launch(android.Manifest.permission.CAMERA)
        } else {
            requestMediaProjection()
        }
    }

    private fun requestMediaProjection() {
        val projectionManager =
            getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        mediaProjectionLauncher.launch(projectionManager.createScreenCaptureIntent())
    }

    private fun startCameraAndGestureRecognition() {
        gestureRecognizerHelper = GestureRecognizerHelper(
            context = this,
            onResult = { gestureName, score -> handleGestureResult(gestureName, score) },
            onError = { message ->
                runOnUiThread { statusText.text = "Status: error - $message" }
            }
        )

        val cameraProviderFuture = ProcessCameraProvider.getInstance(this)
        cameraProviderFuture.addListener({
            cameraProvider = cameraProviderFuture.get()
            bindCameraUseCases()
            isMonitoring = true
            toggleButton.text = "Stop Monitoring"
            statusText.text = "Status: monitoring for ${gestureLabel(selectedGesture)}"
        }, ContextCompat.getMainExecutor(this))
    }

    private fun bindCameraUseCases() {
        val provider = cameraProvider ?: return
        provider.unbindAll()

        val preview = Preview.Builder().build().also {
            it.setSurfaceProvider(previewView.surfaceProvider)
        }

        val imageAnalysis = ImageAnalysis.Builder()
            .setBackpressureStrategy(ImageAnalysis.STRATEGY_KEEP_ONLY_LATEST)
            .build()

        imageAnalysis.setAnalyzer(cameraExecutor) { imageProxy ->
            try {
                val bitmap = imageProxy.toBitmap()
                gestureRecognizerHelper?.recognizeAsync(bitmap, System.currentTimeMillis())
            } catch (e: Exception) {
                Log.e("MainActivity", "Frame analysis failed", e)
            } finally {
                imageProxy.close()
            }
        }

        provider.bindToLifecycle(
            this, CameraSelector.DEFAULT_FRONT_CAMERA, preview, imageAnalysis
        )
    }

    private fun handleGestureResult(gestureName: String, score: Float) {
        if (gestureName != selectedGesture || score < 0.6f) return

        val now = System.currentTimeMillis()
        if (now - lastCaptureTimeMs < cooldownMs) return
        lastCaptureTimeMs = now

        val captured = screenshotService?.captureScreenshot() ?: false
        runOnUiThread {
            statusText.text = if (captured) {
                "Status: captured screenshot on ${gestureLabel(gestureName)}!"
            } else {
                "Status: capture failed, will retry on next gesture"
            }
        }
    }

    private fun gestureLabel(gesture: String) = when (gesture) {
        GestureRecognizerHelper.GESTURE_THUMBS_UP -> "\uD83D\uDC4D Thumbs Up"
        GestureRecognizerHelper.GESTURE_VICTORY -> "\u270C\uFE0F Victory"
        else -> "\u270B Open Palm"
    }

    private fun stopMonitoring() {
        isMonitoring = false
        cameraProvider?.unbindAll()
        gestureRecognizerHelper?.close()
        gestureRecognizerHelper = null
        toggleButton.text = "Start Monitoring"
        statusText.text = "Status: idle"

        if (isServiceBound) {
            unbindService(serviceConnection)
            isServiceBound = false
        }
        stopService(Intent(this, ScreenshotCaptureService::class.java))
    }

    override fun onDestroy() {
        super.onDestroy()
        cameraExecutor.shutdown()
        if (isServiceBound) {
            unbindService(serviceConnection)
        }
    }

    /**
     * Simple YUV_420_888 -> Bitmap conversion via NV21 + JPEG re-encode.
     * Works for the common interleaved-U/V layout most devices (including
     * Samsung Exynos/Snapdragon camera stacks) produce. It's not the fastest
     * possible path, but it's simple, dependency-free, and plenty fast enough
     * for gesture recognition (a few frames per second is all that's needed).
     */
    private fun ImageProxy.toBitmap(): Bitmap {
        val yBuffer = planes[0].buffer
        val uBuffer = planes[1].buffer
        val vBuffer = planes[2].buffer

        val ySize = yBuffer.remaining()
        val uSize = uBuffer.remaining()
        val vSize = vBuffer.remaining()

        val nv21 = ByteArray(ySize + uSize + vSize)
        yBuffer.get(nv21, 0, ySize)
        vBuffer.get(nv21, ySize, vSize)
        uBuffer.get(nv21, ySize + vSize, uSize)

        val yuvImage = YuvImage(nv21, ImageFormat.NV21, width, height, null)
        val out = ByteArrayOutputStream()
        yuvImage.compressToJpeg(Rect(0, 0, width, height), 90, out)
        val jpegBytes = out.toByteArray()
        val rawBitmap = BitmapFactory.decodeByteArray(jpegBytes, 0, jpegBytes.size)

        // Correct sensor rotation and mirror the front-camera feed.
        val matrix = Matrix().apply {
            postRotate(imageInfo.rotationDegrees.toFloat())
            postScale(-1f, 1f)
        }
        return Bitmap.createBitmap(rawBitmap, 0, 0, rawBitmap.width, rawBitmap.height, matrix, true)
    }
}
